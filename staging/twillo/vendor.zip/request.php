<?php
header('Content-type: text/xml');
?>
<Response>
    <Dial callerId="+12544574884"><?php  echo $_POST['To'];?></Dial>
</Response>
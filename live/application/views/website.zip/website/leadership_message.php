<style>
    .close_btn{
position: absolute;
    right: -16px;
    top: -7px;
    opacity: 1;
    background-color: #f9a63e;
    width: 20px;
    height: 20px;
    line-height: 25px;
    font-size: 15px;
    border-radius: 0px;
}
</style>
<body>

<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="blue-header d-flex align-items-center">
    <div class="header-innerPages d-flex align-items-center">
	<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	<div class="header-headingBreadcumb">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2><?php echo  ($this->data['lang']=='en')?@$static_content['leader_page']:@$static_content['leader_page_ar']; ?></h2></div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><ul class="">
			<li><a href="<?php echo base_url(); ?>website/index"><?php echo  ($this->data['lang']=='en')?@$static_content['home']:@$static_content['home_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><?php echo  ($this->data['lang']=='en')?@$static_content['leader_page']:@$static_content['leader_page_ar']; ?></li>
		</ul></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav text-right">
		  <?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
			
		</ul>
		
	</div>  
		
	</div>
    
	</div>
  </header>
<script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>
    
  <section class="leadershipMsgPage-section">
  <div class="leadershipMsgPageMainDiv">
	<div class="container">
	<div class="leadershipMsgPage-title"><h3 class="inner-heading"><?php echo  ($this->data['lang']=='en')?@$static_content['leader_page']:@$static_content['leader_page_ar']; ?></h3></div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
				<div class="leaderShip-SpotlightImgDiv">
					<img src="<?php echo base_url().$leadership['image1']; ?>" class="img-fluid" alt="">
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
				<div class="leadershipMsgPageDiv">
					<h3><?php echo  ($this->data['lang']=='en')?@$leadership['title']:@$leadership['title_ar']; ?></h3>
			    	<?php echo  ($this->data['lang']=='en')?@$leadership['description']:@$leadership['description_ar']; ?>
				</div>
			</div>
			
		</div>
	</div>
	</div>
</section>
<style>
    .modal-header {
     display: block; 
          padding: 0rem 1rem;

    }
    .leadershipMsgPageDiv {
    padding-top: 46px !important;
}
</style>
  
 <section class="imagesPage-section spotlights-section leadershipPagesvideos">
	<div class="villageCommunicationPageMainDiv">
		<div class="leadershipMsgPageDiv"><h3><?php echo  ($this->data['lang']=='en')?@$static_content['explore_more']:@$static_content['explore_more_ar']; ?></h3></div>
		<div class="row">
		     <?php if(!empty($explore_more)){
        foreach($explore_more as $key=> $exploremore){?>
			<div class="col-lg-3 col-md-6 col-sm-3 col-xs-12 ">
				<a href="javascript:" data-bs-toggle="modal" data-bs-target="#modal_video<?= $exploremore['id']?>"><div class="oasis-magazineImgPageDiv-Item magazineImgPageDiv-box">
					<img src="<?php echo base_url().$exploremore['image']; ?>" class="img-fluid" alt="">
					<img src="<?php echo base_url(); ?>assets/website/images/icon-play-circle.png" class="img-fluid play-iconImg" alt=""></a>
					<p><?php echo  ($this->data['lang']=='en')?@($exploremore['title']):($exploremore['title_ar']); ?>
					<!-- if($this->session->userdata['lang']=='en'){-->
					<!--$string = strip_tags(@$exploremore['title']);-->
					<!-- }else{-->
					<!--   	$string = strip_tags(@$exploremore['title_ar']);  -->
					<!-- }-->
					<!--if (strlen($string) > 50) {-->
					<!--?>-->
					
					<!-- <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#member_modal<?= $exploremore['id']?>"><?php echo  ($this->data['lang']=='en')?@$static_content['read_more']:@$static_content['read_more_ar']; ?></a>-->
					<!-- <?php// }?>-->
					 </p>
					
					
				</div>
			</div>
		
		 <?php } } else{?>
       <!--<h4 style="color:red;margin-left: 41%;">No Data found</h4>-->
      <?php }?>

		</div>
	</div>
</section>
  </div>
  
   <?php if(!empty($explore_more)){
        foreach($explore_more as $key=> $exploremore1){?>
  <div class="modal fade" id="modal_video<?= $exploremore1['id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">      
      <div class="modal-body">
       <button type="button" class="btn-close close_btn" data-bs-dismiss="modal" aria-label="Close" onClick="pauseVid()"></button>        
        <!-- 16:9 aspect ratio -->
		<div class="modal_videoDiv">
		    <video width="100%" controls id="myVideo">
			  <source src="<?php echo base_url().$exploremore1['video']; ?>" type="video/mp4">
			  <source src="<?php echo base_url(); ?>assets/website/images/bp-video.ogg" type="video/ogg">
			</video>
		</div>
      </div>
    </div>
  </div>
</div> 
<?php  } }?>
<?php if(!empty($explore_more)){
        foreach($explore_more as $key=> $explore_more2){?>

<div class="modal fade" id="member_modal<?= $explore_more2['id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">      
      <div class="modal-body">
          <div class="modal-header">
           <span class="modal-title" style="margin-left: 33%;"><b><?php echo  ($this->data['lang']=='en')?@$static_content['details']:@$static_content['details_ar']; ?></b></span>
       <button type="button" class="btn-close close_btn" data-bs-dismiss="modal" aria-label="Close" onClick="pauseVidnew()" style="top: 1px;margin-top: 1p;left: 13px;margin-right: 1px;"></button>        
     </div>
		<div class="modal_videoDiv">
		    <p><?php echo  ($this->data['lang']=='en')?@$explore_more2['title']:@$explore_more2['title_ar']; ?></p>
        
		</div>
      </div>
    </div>
  </div>
</div>
<?php } }?>

<!--<div class="modal fade" id="modal_videoOne" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">      
      <div class="modal-body">
       <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick="pauseVidnew()"></button>        
     
		<div class="modal_videoDiv">
		    <video width="100%" controls id="myVideoneww">
			  <source src="<?php echo base_url(); ?>assets/website/images/bp-video.mp4" type="video/mp4">
			  <source src="<?php echo base_url(); ?>assets/website/images/bp-video.ogg" type="video/ogg">
			</video>
		</div>
      </div>
    </div>
  </div>
</div> -->

<script> 
var vid = document.getElementById("myVideo"); 
function pauseVid() { 
  vid.pause(); 
} 
</script> 

<script>
var vidi = document.getElementById("myVideoneww"); 
function pauseVidnew() { 
  vidi.pause(); 
}
</script>
  
</body>
</html>



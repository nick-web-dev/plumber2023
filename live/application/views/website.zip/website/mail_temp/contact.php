<!Doctype html>
<html>
<head>
<meta charset="utf-8">
<title>New Contact Request</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
</head>
<body style="font-family: 'Open Sans',sans-serif; margin:0px auto; font-size:15px; width:100%;">
<div class="main-div"  style="width: 75%;margin:20px auto; height:auto;border: 1px solid #ccc;">
  <div class="content" style="width:100%; margin:0px auto;">
    <div class="top-header" style="width: 100%;padding-bottom: 100px;padding-top: 10px;background: #f2f2f2;border-bottom: 1px solid #ccc;">
      <div class="logo" style=" float:left; width:22%"> 
        <a href="<?php echo base_url();?>"> <img  src="<?php echo base_url();?>assets/website/img/logo.png" alt="logo" style="width:90px; height:auto;margin-left: 10px;"></a> </div>
      <div class="header-content" style=" float:left; width:70%">
      <h3 class="" style="margin-bottom: 0px;font-size: 25px;color: #1D2C39;font-weight: 600;line-height: 18px;margin-top: 35px;  text-transform: uppercase;text-align: center;">New Contact Request</h3>
    
      </div>
    </div>
    <div class="content" style="width:100%;padding: 15px 20px;">
        <!-- <p style="width:90%; text-transform:uppercase ;text-align:center;    font-size: 20px;
      color: #0d7e52;"><strong>Password Details</strong></p> -->
      <p style="margin-bottom:10px;text-align:center;width: 25%;float: left;">
        <strong>Name</strong>
        <span style="width: 10%;float: right;">:</span>
      </p>
      <p style="text-align:left;width: 75%;float: left;width: 70%;float: left; padding-left: 20px;">{name}</p>

      <p style="margin-bottom:10px;text-align:center;width: 25%;float: left;">
        <strong>Email</strong>
        <span style="width: 10%;float: right;">:</span>
      </p>
      <p style="text-align:left;width: 75%;float: left;width: 70%;float: left; padding-left: 20px;">{email}</p>

      <p style="margin-bottom:10px;text-align:center;width: 25%;float: left;">
        <strong>Mobile</strong>
        <span style="width: 10%;float: right;">:</span>
      </p>
      <p style="text-align:left;width: 75%;float: left;width: 70%;float: left; padding-left: 20px;">{phone}</p>

      <p style="margin-bottom:10px;text-align:center;width: 25%;float: left;">
        <strong>Message</strong>
        <span style="width: 10%;float: right;">:</span>
      </p>
      <p style="text-align:left;width: 75%;float: left;width: 70%;float: left; padding-left: 20px;">{message}</p>

      <div style="background-color: #ddd; padding: 2px 20px;">
        <p align="center" style="  font-size: 13px;color: #333;letter-spacing: 0.5px;font-weight: 600;">Copyright ©2020 <a href="javascript:" style="color:#1D2C39; text-decoration:none;">DroitVeritasLaw</a> All Rights Reserved
        </p>
      </div>
    </div>
  </div>
</body>
</html>
<style>
    .close_btn{
position: absolute;
    right: -16px;
    top: -7px;
    opacity: 1;
    background-color: #f9a63e;
    width: 20px;
    height: 20px;
    line-height: 25px;
    font-size: 15px;
    border-radius: 0px;
}
</style>
<body>

<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="blue-header d-flex align-items-center">
    <div class="header-innerPages d-flex align-items-center">
	<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	<div class="header-headingBreadcumb">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2><?php echo  ($this->data['lang']=='en')?@$static_content['spotlights']:@$static_content['spotlights_ar']; ?></h2></div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><ul class="">
			<li><a href="<?php echo base_url(); ?>website/index"><?php echo  ($this->data['lang']=='en')?@$static_content['home']:@$static_content['home_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><?php echo  ($this->data['lang']=='en')?@$static_content['spotlights']:@$static_content['spotlights_ar']; ?></li>
		</ul></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav text-right">
			 <?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
		</ul>
	</div> 
	</div>
    
	</div>
  </header>
<script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>
  <section class="imagesPage-section spotlights-section">
	<div class="villageCommunicationPageMainDiv">
		<div class="row">
		      <?php if(!empty($spotlight)){
        foreach($spotlight as $key=> $spotlightes){?>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
			    <?php if($spotlightes['type']==2){?>
				<a href="javascript:" data-bs-toggle="modal" data-bs-target="#modal_video<?= $spotlightes['id']?>"><div class="oasis-magazineImgPageDiv-Item">
					<img src="<?php echo base_url().$spotlightes['image']; ?>" class="img-fluid" alt="">
					<img src="<?php echo base_url(); ?>assets/website/images/icon-play-circle.png" class="img-fluid play-iconImg" alt=""></a>
					<?php } else{?>
					<div class="oasis-magazineImgPageDiv-Item">
					<a href="<?php echo $spotlightes['link'];?>" target="_blank"><img src="<?php echo base_url().$spotlightes['image']; ?>" class="img-fluid" alt=""></a>
	
					<?php }?>
					
					<p><?php echo  ($this->data['lang']=='en')?@$spotlightes['description']:$spotlightes['description_ar']; ?>
				 	<?//php echo  ($this->data['lang']=='en')?@substr(($spotlightes['description']),0,90):substr(($spotlightes['description_ar']),0,150); 
				// 	 if($this->session->userdata['lang']=='en'){
				// 	$string = strip_tags(@$spotlightes['description']);
				// 	 }else{
				// 	   	$string = strip_tags(@$spotlightes['description_ar']);  
				// 	 }
				// 	if (strlen($string) > 90) {
					//?>
					
					 <!--<a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#member_modal<?//= $spotlightes['id']?>"><?//php echo  ($this->data['lang']=='en')?@$static_content['read_more']:@$static_content['read_more_ar']; ?></a>-->
					 <?//php }?>
					 </p>
				</div>
			</div>
			<?php  } }?>
		</div>
	</div>
</section>
  

  
  </div>
  
 <?php if(!empty($spotlight)){
        foreach($spotlight as $key=> $spotlighte2){?>
        
<div class="modal fade" id="modal_video<?= $spotlighte2['id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">      
      <div class="modal-body">
       <button type="button" class="btn-close close_btn" data-bs-dismiss="modal" aria-label="Close" onClick="pauseVid()"></button>        
        <!-- 16:9 aspect ratio -->
		<div class="modal_videoDiv">
		    <video width="100%" controls id="myVideo">
			  <source src="<?php echo base_url().$spotlighte2['video']; ?>" type="video/mp4">
			  <source src="<?php echo base_url(); ?>assets/website/images/bp-video.ogg" type="video/ogg">
			</video>
		</div>
      </div>
    </div>
  </div>
</div> 
</div>
<?php } }?>
<?php if(!empty($spotlight)){
        foreach($spotlight as $key=> $spotlight1){?>

<div class="modal fade" id="member_modal<?= $spotlight1['id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">      
      <div class="modal-body">
          <div class="modal-header">
           <span class="modal-title" style="margin-left: 33%;"><b><?php echo  ($this->data['lang']=='en')?@$static_content['details']:@$static_content['details_ar']; ?></b></span>
       <button type="button" class="btn-close close_btn" data-bs-dismiss="modal" aria-label="Close" onClick="pauseVidnew()" style="top: 1px;margin-top: 1p;left: 13px;margin-right: 1px;"></button>        
     </div>
		<div class="modal_videoDiv">
		    <p><?php echo  ($this->data['lang']=='en')?@$spotlight1['description']:@$spotlight1['description_ar']; ?></p>
        
		</div>
      </div>
    </div>
  </div>
</div>
<?php } }?>


<!--<div class="modal fade" id="modal_videoOne" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">-->
<!--  <div class="modal-dialog" role="document">-->
<!--    <div class="modal-content">      -->
<!--      <div class="modal-body">-->
<!--       <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick="pauseVidnew()"></button>        -->
        <!-- 16:9 aspect ratio -->
<!--		<div class="modal_videoDiv">-->
<!--		    <video width="100%" controls id="myVideoneww">-->
<!--			  <source src="<?php echo base_url(); ?>assets/website/images/bp-video.mp4" type="video/mp4">-->
<!--			  <source src="<?php echo base_url(); ?>assets/website/images/bp-video.ogg" type="video/ogg">-->
<!--			</video>-->
<!--		</div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div> -->

<script> 
var vid = document.getElementById("myVideo"); 
function pauseVid() { 
  vid.pause(); 
} 
</script> 

<script>
var vidi = document.getElementById("myVideoneww"); 
function pauseVidnew() { 
  vidi.pause(); 
}
</script>

<!--<script>
$(document).ready(function() {

  $('#modal_videoOne').modal({
	  show: false
  }).on('hidden.bs.modal', function(){
	  $(this).find('video')[0].pause();
  });

});
</script>-->

</body>
</html>



  <style>
.error {
    color: red !important;
}
.head{
    background-color: #5af096 !important;
    padding: 6px !important;
    color: white !important;
}
.head_title {
    display: block;
    margin-left: auto;
}
.modal_content {
    width: 155%;
}
.blog-c{
       background-color: #5af096 !important;
}
.modal-footer {
border-top: 1px solid black;
}
 .modal-header .btn-close {
    width: 10px;
    height: 10px;
    line-height: 10px;
    padding: 6px;
    font-size: 9px;
    font-weight: 600;
    border: 2px
    solid #444444;
    border-radius: 50%;
}
.modal-header {
    border-bottom: 0px solid #dee2e6 !important;
}
</style>

  <div class="modal-dialog tech_tood-model" role="document">
    <div class="modal-content modal_content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      
      <div class="modal-body">
        <form id="topic_form" method="post" enctype='multipart/form-data' >
		  
                   
		    <div class="modal-body">
        <div class="villageCommunicationmodel-details">
	<div class="villageCommunicationmodel-headingtagline">
		<h3><?php echo  ($this->data['lang']=='en')?@$villagecommunications['title']:@$villagecommunications['title_ar']; ?></h3>
	<?php echo  ($this->data['lang']=='en')?@$villagecommunications['description']:@$villagecommunications['description_ar']; ?>
	</div>
	<div class="villageCommunicationmodel-yearsBoxs">
		<div class="row yearsBoxsDiv">
		    <?php if(!empty($year_details)){
               foreach($year_details as $key=> $yeardetails){?>
			<span class="yearsBoxs"><a href="<?php echo base_url(); ?>website/villagecommunication_images/<?php echo base64_encode($yeardetails['vc_type_id'])?>/<?php echo base64_encode($yeardetails['date']);?>"><?php echo $yeardetails['date'];?></a></span>
		 <?php } } ?>
     
		</div>
		
	</div>
 </div>
      </div>
	      </form>
    </div>
  </div>
</div>

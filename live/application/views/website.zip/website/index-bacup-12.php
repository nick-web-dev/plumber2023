<body>
<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="headerHome d-flex align-items-center">
	<div class="col-lg-4 col-md-4 col-sm-4">
	<div class="logoDiv d-flex align-items-center justify-content-left">
		<div class="logo_headerDiv"><a href="index.html"><img src="<?php echo base_url(); ?>assets/website/images/logo-header.png" class="img-fluid" alt=""></a></div>
	</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6">
	<div class="headerCenterDiv d-flex align-items-center justify-content-center">
		<div class="headerCenterImgDiv"><a href="index.html"><img src="<?php echo base_url(); ?>assets/website/images/logo-header-center.png" class="img-fluid logo-footer" alt=""></a></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav  text-right">
		     <?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
		</ul>
	</div>  
	</div>
    
	</div>
  </header>
  <section class="banner-section">
	<div class="banner-sectionmain">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<div class="leaderShip-SpotlightDiv">
					<a href="<?php echo base_url(); ?>website/leadership_message"><div class="leaderShip-SpotlightImgDiv">
						<img src="<?php echo base_url().$leadership['image']; ?>" class="img-fluid" alt="">
						<div class="leaderShip-Spotlight-title"><h3> <?php echo  ($this->data['lang']=='en')?@$leadership['title']:@$leadership['title_ar']; ?></h3></div>
					</div></a>
				</div>
				
				<div class="leaderShip-SpotlightDiv">
					<div class="leaderShip-SpotlightSlider ">
						<div class="leaderShip-SpotlightSlider swiper">
						<div class="swiper-wrapper align-items-center">
						       <?php if(!empty($spotlight)){
        foreach($spotlight as $key=> $spotlights){?>
							<div class="swiper-slide">
							<div class="swiper_item">
							<img src="<?php echo base_url().$spotlights['image']; ?>" class="img-fluid" alt="">
							<div class="leaderShip-Spotlight-title"><h3><?php echo  ($this->data['lang']=='en')?@$spotlights['title']:@$spotlights['title_ar']; ?></h3><a href="<?php echo base_url(); ?>website/spotlight" class="view-all">View All</a></div>
							</div>
							</div>
							 <?php } } else{?>
       <h4 style="color:red;">No data found</h4>
      <?php }?>

						
						</div>
						<div class="swiper-pagination"></div>
					</div>
					
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<div class="vCommunicatin-omDiv">
					<div class="vCommunicatin-omImgDiv"><img src="<?php echo base_url().$village_Communications['image']; ?>" class="img-fluid" alt=""></div>
					<div class="leaderShip-Spotlight-title"><h3><?php echo  ($this->data['lang']=='en')?@$village_Communications['title']:@$village_Communications['title_ar']; ?></h3> <a href="<?php echo base_url(); ?>website/village_communication" class="view-all">View All</a></div>
				</div>
				<?php
				 $arr = explode("-", $oasis_magazine['date']);
                 $day  = date('d', strtotime($oasis_magazine['date']));
                 $date=$day.'/'.$arr[1];
				?>
				
				<div class="oasis-mgDiv">
					<div class="oasis-mgImgDiv"><img src="<?php echo base_url().$oasis_magazine['image']; ?>" class="img-fluid" alt=""> <span class="post-date"><?php echo $date;?></span></div>
					<div class="browseByBeedImg-title"><h3><?php echo  ($this->data['lang']=='en')?@$oasis_magazine['title']:@$oasis_magazine['title_ar']; ?></h3> <a href="<?php echo base_url(); ?>website/oasis_magazine" class="view-all">View All</a></div>
				</div>
				
				
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<div class="villageHappeningsDiv ">
					<div class="vHappening-slider swiper">
						<div class="swiper-wrapper align-items-center">
						      <?php if(!empty($village_happening)){
        foreach($village_happening as $key=> $villagehappening){?>
							<div class="swiper-slide">
							<div class="swiper_item"><a href="<?php echo base_url(); ?>website/village_happenings">
							<img src="<?php echo base_url().$villagehappening['image']; ?>" class="img-fluid" alt="">
							<div class="leaderShip-Spotlight-title"><h3><?php echo  ($this->data['lang']=='en')?@$villagehappening['title']:@$villagehappening['title_ar']; ?></h3></div>
							</a></div>
							</div>
										 <?php } } else{?>
       <h4 style="color:red;">No data found</h4>
      <?php }?>

						</div>
						<div class="swiper-pagination"></div>
						  <!-- navigation buttons -->
					  <div id="js-prev1" class="swiper-button-prev"></div>
					  <div id="js-next1" class="swiper-button-next"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
 
 <section class="askquerries-section">
 <div class="row">
 <div class="container">
 <p><?php echo  ($this->data['lang']=='en')?@$static_content['please_ask_title']:@$static_content['please_ask_title_ar']; ?>  <a  href="<?php echo $mylinks[0]['link']; ?>" target="_blank" class="color-orange"><?php echo  ($this->data['lang']=='en')?@$static_content['click_here']:@$static_content['click_here']; ?></a></p>
 </div>
 </div>
 </section>
 
 
 <section class="myLinks-eventCalender">
	<div class="d-flex align-items-center">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-5 ">
				<div class="mylinks-div">
					<h3>My Links</h3>
					<p><?php echo  ($this->data['lang']=='en')?@$static_content['my_link']:@$static_content['my_link_ar']; ?></p>
					<ul class="list-inline">
						<li><a  href="<?php echo $mylinks[1]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[1]['title']:@$mylinks[1]['title_ar']; ?></a></li>
						<li><a  href="<?php echo $mylinks[2]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[2]['title']:@$mylinks[2]['title_ar']; ?></a></li>
						<li><a  href="<?php echo base_url(); ?>website/ps_policies"><?php echo  ($this->data['lang']=='en')?@$static_content['policies']:@$static_content['policies_ar']; ?></a></li>
						<li><a  href="<?php echo $mylinks[3]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[3]['title']:@$mylinks[3]['title_ar']; ?></a></li>
						<li><a  href="<?php echo $mylinks[4]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[4]['title']:@$mylinks[4]['title_ar']; ?></a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-7 col-md-7 col-sm-7">
				<div class="eventCalender-div">	
					<h3 class="text-center">Corporate Calendar</h3>
					<div id="calendar"></div>
					<ul class="d-inline">
						<li class="red-clr"><a href="javascript:" >Event</a></li>
						<li class="merun-clr"><a href="javascript:">Party</a></li>
						<li><a href="javascript:">Holidays</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
 </section>

<!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container footer-top">
      <div class="footer-topmain">
        <div class="row">

          <div class="col-lg-3 col-md-3 footer-contact">
            <div class="logo_footerDiv"><img src="<?php echo base_url(); ?>assets/website/images/logo-white.png" class="img-fluid logo-footer" alt=""></div>
          </div>

          <div class="col-lg-6 col-md-6 footer-links">
            <p><?php echo  ($this->data['lang']=='en')?@$static_content['please_ask_title']:@$static_content['please_ask_title_ar']; ?><a href="<?php echo $mylinks[0]['link']; ?>" target="_blank" class="color-orange"><?php echo  ($this->data['lang']=='en')?@$static_content['click_here']:@$static_content['click_here']; ?></a></p>
          </div>
		  
		  <div class="col-lg-3 col-md-3 footer-links social-div3">
            <h4>DaVita Social Media</h4>
           <ul>
              <li><a href="<?php echo $static_content['twitter_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon1.png" class="img-fluid" alt=""></a></li>
              <li><a href="<?php echo $static_content['instagram_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon2.png" class="img-fluid" alt=""></a></li>
              <li><a href="<?php echo $static_content['data[linked_link]']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon3.png" class="img-fluid" alt=""></a></li>
			  <li><ahref="<?php echo $static_content['web_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon4.png" class="img-fluid" alt=""></a></li>
            </ul>
          </div>


        </div>
      </div>
    </div>

    <div class="footer-bottm">
      <div class="d-flex w-100  text-center text-lg-center">
        <div class="copyright w-100 text-center">
             <h5><?php echo  ($this->data['lang']=='en')?@$static_content['all_rights']:@$static_content['all_rights_ar']; ?></h5>
		   <p><?php echo  ($this->data['lang']=='en')?@$static_content['test']:@$static_content['test_ar']; ?>
</p>
        </div>
      </div>
      
    </div>
  </footer><!-- End Footer -->
  
  </div>
  <script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>
    
  
  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>assets/website/js/aos.js"></script>
  <script src="<?php echo base_url(); ?>assets/website/js/bootstrap.bundle.min.js"></script>
  <script src='<?php echo base_url(); ?>assets/website/js/moment.min.js'></script>
  <script src='<?php echo base_url(); ?>assets/website/js/jquery.min.js'></script>
  <script src="<?php echo base_url(); ?>assets/website/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/website/js/swiper-bundle.min.js"></script>
<script>
      var swiper = new Swiper(".leaderShip-SpotlightSlider", {
        slidesPerView: 1,
        spaceBetween: 10,
		autoplay: {
		  delay: 5000,
		},
		pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });
    </script>
<script>
      var swiper = new Swiper(".vHappening-slider", {
        slidesPerView: 1,
        spaceBetween: 10,
		autoplay: {
		  delay: 4000,
		},
		navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
		pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });
    </script>
  <!--<script src="js/main.js"></script>-->
  
 <script src='<?php echo base_url(); ?>assets/website/js/fullcalendar.min.js'></script>
<script src='<?php echo base_url(); ?>assets/website/js/theme-chooser.js'></script>
<script>

	$(document).ready(function() {

		initThemeChooser({

			init: function(themeSystem) {
				$('#calendar').fullCalendar({
					themeSystem: themeSystem,
					header: {
						left: 'prev,next today',
						center: 'title',
						right: 'month,agendaWeek,agendaDay,listMonth'
					},
					defaultDate: '2021-10-14',
					weekNumbers: true,
					navLinks: true, // can click day/week names to navigate views
					editable: true,
					eventLimit: true, // allow "more" link when too many events
					events: [
						{
							title: 'All Day Event',
							start: '2021-10-05',
							end: '2021-10-05'
						},
						{
							title: 'Long Event',
							start: '2021-10-25',
							end: '2021-10-25'
						},
						{
							id: 999,
							title: 'Repeating Event',
							start: '2021-10-015T16:00:00'
						},
						{
							id: 999,
							title: 'Repeating Event1',
							start: '2021-10-18T16:00:00'
						},
						{
							title: 'Conference',
							start: '2021-11-11',
							end: '2021-11-13'
						},
						{
							title: 'Meeting',
							start: '2021-11-12T10:30:00',
							end: '2021-11-12T12:30:00'
						},
						{
							title: 'Lunch',
							start: '2021-11-12T12:00:00'
						},
						{
							title: 'Meeting',
							start: '2021-10-12T14:30:00'
						},
						{
							title: 'Happy Hour',
							start: '2021-11-05T17:30:00'
						},
						{
							title: 'Dinner',
							start: '2021-10-12T20:00:00'
						},
						{
							title: 'Birthday Party',
							start: '2021-10-14T07:00:00'
						},
						{
							title: 'Click for Google',
							url: 'http://google.com/',
							start: '2021-11-28'
						}
					]
				});
			},

			change: function(themeSystem) {
				$('#calendar').fullCalendar('option', 'themeSystem', themeSystem);
			}

		});

	});

</script>


</body>
</html>



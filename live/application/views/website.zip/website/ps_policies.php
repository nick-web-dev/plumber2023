<style>
/*    .swiper-button-lock {*/
/*    display: inline-flex;*/
/*}*/
</style>
<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="blue-header d-flex align-items-center">
    <div class="header-innerPages d-flex align-items-center">
	<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	<div class="header-headingBreadcumb">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2><?php echo  ($this->data['lang']=='en')?@$static_content['policies']:@$static_content['policies_ar']; ?></h2></div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><ul class="">
			<li><a href="<?php echo base_url(); ?>website/index"><?php echo  ($this->data['lang']=='en')?@$static_content['home']:@$static_content['home_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><?php echo  ($this->data['lang']=='en')?@$static_content['policies']:@$static_content['policies_ar']; ?></li>
		</ul></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav text-right">
			  <?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
		</ul>
	</div> 
	</div>
    
	</div>
  </header>
  <script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>

  <section class="psPoliciesPage-section">
  <div class="leadershipMsgPageMainDiv">
	<div class="container">
	<div class="leadershipMsgPage-title">
	<h3 class="text-center"><?php echo  ($this->data['lang']=='en')?@$static_content['policies']:@$static_content['policies_ar']; ?></h3>
	<p><?php echo  ($this->data['lang']=='en')?@$static_content['policies_text']:@$static_content['policies_text_ar']; ?></p>
	</div>
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
				<div class="psPoliciesPageDiv">
                <div class="nav-tabs-slider swiper">
					<ul class="nav nav-tabs swiper-wrapper">
					       <?php if(!empty($policies)){
        foreach($policies as $key=> $policie){?>
					  <li class="nav-item swiper-slide">
						<a class="nav-link <?=($key==0)?'active':'';?>"  data-bs-toggle="tab" href="#tabcontent<?= $policie['id']?>"><?php echo  ($this->data['lang']=='en')?@$policie['title']:@$policie['title_ar']; ?></a>
					  </li>
					   <?php } } ?>
					</ul>
                    <div id="js-prev1" class="swiper-button-prev"></div>
					<div id="js-next1" class="swiper-button-next"></div>
				</div>
                	
					<div class="tab-content">
					     <?php if(!empty($policies)){
        foreach($policies as $key1=> $policie_n){?>
						<div id="tabcontent<?= $policie_n['id']?>" class="tab-pane fade in show <?=($key1==0)?'active':'';?>">
							<h3 class="inner-heading"><span><?php echo  ($this->data['lang']=='en')?@$policie_n['title']:@$policie_n['title_ar']; ?></span></h3>
						 <a href="<?php echo base_url().$policie_n['image']; ?>" download><img src="<?php echo base_url(); ?>assets/website/images/pdf_img.png" class="img-fluid" alt=""></a>
						</div>
						   <?php } } ?>
					
					</div>
				</div>
			</div>
			
		</div>
	</div>
	</div>
</section>
  
 
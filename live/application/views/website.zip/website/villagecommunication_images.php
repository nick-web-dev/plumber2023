<body>

<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="blue-header d-flex align-items-center">
    <div class="header-innerPages d-flex align-items-center">
	<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	<div class="header-headingBreadcumb">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2><?php echo  ($this->data['lang']=='en')?@$static_content['image']:@$static_content['image_ar']; ?></h2></div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><ul class="">
			<li><a href="<?php echo base_url(); ?>website/index"><?php echo  ($this->data['lang']=='en')?@$static_content['home']:@$static_content['home_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><a href="<?php echo base_url(); ?>website/village_communication"><?php echo  ($this->data['lang']=='en')?@$static_content['village_communication']:@$static_content['village_communication_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><?php echo  ($this->data['lang']=='en')?@$static_content['image']:@$static_content['image_ar']; ?></li>
		</ul></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav text-right">
		 <?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
		</ul>
	</div>  
	
	</div>
    
	</div>
  </header>
  <script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>

  <section class="imagesPage-section">
	<div class="villageCommunicationPageMainDiv">
		<div class="row">
		     <?php if(!empty($images)){
                foreach($images as $img){?>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<div class="oasis-magazineImgPageDiv-Item">
				      <?php if($img['type']==1){?>
					<a href="<?php echo $img['link'];?>" target="_blank"><img src="<?php echo base_url().$img['image']; ?>" class="img-fluid" alt="" style=" height: 262px; width: 373px;"></a>
				<?php } else {?>
					<a href="<?php echo base_url().$img["pdf"];?>" target="_blank"><img src="<?php echo base_url().$img['image']; ?>" class="img-fluid" alt="" style=" height: 262px; width: 373px;"></a>
				<?php }?>
				    <p><b><?php echo  ($this->data['lang']=='en')?@$img['title']:@$img['title_ar']; ?></b></p>
				
				</div>
			</div>
		  <?php } } else{?>
  <h3 style="color:red;text-align: center;">No Imges</h3>
  <?php }?>
		
		</div>
	</div>
</section>
  
 


  
  </div>
  



</body>
</html>


<body>
<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="blue-header d-flex align-items-center">
    <div class="header-innerPages d-flex align-items-center">
	<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	<div class="header-headingBreadcumb">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2><?php echo  ($this->data['lang']=='en')?@$static_content['village_communication']:@$static_content['village_communication_ar']; ?></h2></div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><ul class="">
			<li><a href="<?php echo base_url(); ?>website/index"><?php echo  ($this->data['lang']=='en')?@$static_content['home']:@$static_content['home_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><?php echo  ($this->data['lang']=='en')?@$static_content['village_communication']:@$static_content['village_communication_ar']; ?></li>
		</ul></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav text-right">
		<?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
		</ul>
	</div>  
	</div>
    
	</div>
  </header>
  <script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>

  <section class="villageCommunicationPage-section">
	<div class="container">
		<div class="row">
		    
			<!--<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">-->
			<!--	<a href="javascript:" data-bs-toggle="modal" data-bs-target="#exampleModal"><div class="villageCommunicationPageDiv-Item">-->
			<!--		<h4>Common Myths of Peritoneal Dialysis(PD)</h4>-->
			<!--	</div></a>-->
			<!--</div>-->
			      <?php if(!empty($village_communications_types)){
		           $color = array('#0067B1','#EF7F01','#D31056','#641480;','#128094;','#0067B1','#EF7F01','#D31056','#641480;','#128094;','#0067B1','#EF7F01','#D31056','#641480;','#128094;','#0067B1','#EF7F01','#D31056','#641480;','#128094;');
                     $ci =0;
		           
        foreach($village_communications_types as $key=> $villagecommunicationstypes){
                $ci = ($ic>4)? 0: $ci;?>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<a type="button" class="add_banners" data-id="<?php echo $villagecommunicationstypes['id'];?>">
				    <div class="villageCommunicationPageDiv-Item" style="background-color: <?php echo $color[$ci]?>;width: 359px;">
					<h4><?php echo  ($this->data['lang']=='en')?@$villagecommunicationstypes['title']:@$villagecommunicationstypes['title_ar']; ?></h4>
				</div></a>
				<!--<button type="button" class="add_banners" data-lat="1">-->
    <!--       </button>-->
			</div>
				
		 <?php $ci++;} } else{?>
       <h4 style="color:red;margin-left: 41%;">No Data found</h4>
      <?php }?>
		
		</div>
	</div>
</section>
  
 
 
 

<!-- ======= Footer ======= -->
 <!-- Modal -->
<!--<div class="modal fade villageCmnctmodal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">-->
<!--  <div class="modal-dialog modal-lg">-->
<!--    <div class="modal-content">-->
<!--      <div class="modal-header">-->
<!--        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>-->
<!--      </div>-->
<!--      <div class="modal-body">-->
<!--        <div class="villageCommunicationmodel-details">-->
<!--	<div class="villageCommunicationmodel-headingtagline">-->
<!--		<h3>Common Myths of Peritoneal Dialysis(PD)</h3>-->
<!--		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. -->
<!--		Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley</p>-->
<!--	</div>-->
<!--	<div class="villageCommunicationmodel-yearsBoxs">-->
<!--		<div class="row yearsBoxsDiv">-->
<!--			<span class="yearsBoxs"><a href="javascript:" class="active">2011</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2012</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2013</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2014</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2015</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2016</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2017</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2018</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2019</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2020</a></span>-->
<!--			<span class="yearsBoxs"><a href="javascript:">2021</a></span>-->
<!--		</div>-->
		
<!--	</div>-->
<!-- </div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
  
  </div>
 

</body>
</html>
 <div class = "modal fade" data-backdrop="static" data-keyboard="false" id = "add_banners" tabindex = "-1" role = "dialog" aria-labelledby = "myModalLabel" aria-hidden = "true"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
$(document).ready(function () 
  {
    var $modal = $('#add_banners');
   // var $modal2 = $('#edit_banners');
    $('.add_banners').on('click',function(event){
      var id= $(this).data('id'); 
     
// 	  alert(offerid);
      event.stopPropagation();
      $modal.load('<?php echo site_url('website/get_communications');?>', {id:id},
      function(){
      $modal.modal('show');
      });
    }); 
	 });
  </script>
<script>



<body>

<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="blue-header d-flex align-items-center">
    <div class="header-innerPages d-flex align-items-center">
	<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	<div class="header-headingBreadcumb">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2><?php echo  ($this->data['lang']=='en')?@$static_content['village_happenings']:@$static_content['village_happenings_ar']; ?></h2></div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><ul class="">
			<li><a href="<?php echo base_url(); ?>website/index"><?php echo  ($this->data['lang']=='en')?@$static_content['home']:@$static_content['home_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><?php echo  ($this->data['lang']=='en')?@$static_content['village_happenings']:@$static_content['village_happenings_ar']; ?></li>
		</ul></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav text-right">
		 <?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
		</ul>
	</div> 

	</div>
    
	</div>
  </header>
  <script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>

  <section class="villageCommunicationPage-section">
	<div class="container">
		<div class="row">
		       <?php if(!empty($village_happening_types)){
		           $color = array('#0067B1','#EF7F01','#D31056','#641480;','#128094;','#0067B1','#EF7F01','#D31056','#641480;','#128094;','#0067B1','#EF7F01','#D31056','#641480;','#128094;','#0067B1','#EF7F01','#D31056','#641480;','#128094;');
                     $ci =0;
		           
        foreach($village_happening_types as $key=> $villagehappeningtypes){
 $ci = ($ic>4)? 0: $ci;      
        ?>
        
			<div class="col-lg-4 col-md-6 col-sm-4 col-xs-12 ">
				<a href="<?php echo base_url(); ?>website/images/<?php echo base64_encode($villagehappeningtypes['id']);?>"><div class="villageCommunicationPageDiv-Item" style="background-color: <?php echo $color[$ci]?>;">
					<h4><?php echo  ($this->data['lang']=='en')?@$villagehappeningtypes['title']:@$villagehappeningtypes['title_ar']; ?></h4>
				</div></a>
			</div>
				
		 <?php $ci++;} } else{?>
       <h4 style="color:red;margin-left: 41%;">No Data found</h4>
      <?php }?>
		<!--	<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<a href="images.html">
				    <div class="villageCommunicationPageDiv-Item yellow-clr">
					<h4>Lorem Ipsum is simply Ipsum has been Ipsum has been</h4>
				</div></a>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<a href="images.html"><div class="villageCommunicationPageDiv-Item red-clr">
					<h4>Lorem Ipsum is simply Ipsum has been Ipsum has been</h4>
				</div></a>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<a href="images.html"><div class="villageCommunicationPageDiv-Item voilit-clr">
					<h4>Lorem Ipsum is simply Ipsum has been Ipsum has been</h4>
				</div></a>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<a href="images.html"><div class="villageCommunicationPageDiv-Item meroon-clr">
					<h4>Lorem Ipsum is simply Ipsum has been Ipsum has been</h4>
				</div></a>
			</div>-->
		</div>
	</div>
</section>
  
 


  
  </div>
 

</body>
</html>



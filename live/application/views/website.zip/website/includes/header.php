<!DOCTYPE html>
<html lang="en">
<head>
  <title>Davita</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="<?php echo base_url(); ?>assets/website/images/favicon.png" tppabs="<?php echo base_url(); ?>assets/website/images/favicon.png" type="image/x-icon">
  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url(); ?>assets/website/css/aos.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/website/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/website/css/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/website/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/website/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/website/css/swiper-bundle.min.css" rel="stylesheet">
<link href='<?php echo base_url(); ?>assets/website/css/fullcalendar.min.css' rel='stylesheet' />
<link href='<?php echo base_url(); ?>assets/website/css/fullcalendar.print.min.css' rel='stylesheet' media='print' />
<!-- <link href="http://db.onlinewebfonts.com/c/1e1ee1ec762e9ee51ae4633db26665fd?family=Bree+Rg" rel="stylesheet" type="text/css"/> -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
     
  <link href="<?php echo base_url(); ?>assets/website/css/style.css" rel="stylesheet">
   <link href="<?php echo base_url(); ?>assets/website/css/responsive.css" rel="stylesheet">
  <?php if($this->session->userdata['lang']=='ar'){?>
  <link href="<?php echo base_url(); ?>assets/website/css/arabic.css" rel="stylesheet">
  <?php } ?>

  <style>
 
  </style>
</head>
<!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container footer-top">
      <div class="footer-topmain">
        <div class="row">

          <div class="col-lg-3 col-md-3 footer-contact">
            <div class="logo_footerDiv"><img src="<?php echo base_url(); ?>assets/website/images/logo-white.png" class="img-fluid logo-footer" alt=""></div>
          </div>

          <div class="col-lg-6 col-md-6 footer-links">
            <p><?php echo  ($this->data['lang']=='en')?@$static_content['please_ask_title']:@$static_content['please_ask_title_ar']; ?>  <a  href="<?php echo $mylinks[0]['link']; ?>" target="_blank" class="color-orange"><?php echo  ($this->data['lang']=='en')?@$static_content['click_here']:@$static_content['click_here_ar']; ?></a></p>
          </div>
		  
		  <div class="col-lg-3 col-md-3 footer-links social-div3">
            <h4><?php echo  ($this->data['lang']=='en')?@$static_content['socail_media']:@$static_content['socail_media_ar']; ?> </h4>
            <ul>
              <li><a href="<?php echo $static_content['twitter_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon1.png" class="img-fluid" alt=""></a></li>
              <li><a href="<?php echo $static_content['instagram_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon2.png" class="img-fluid" alt=""></a></li>
              <li><a href="<?php echo $static_content['linked_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon3.png" class="img-fluid" alt=""></a></li>
			  <li><a href="<?php echo $static_content['web_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon4.png" class="img-fluid" alt=""></a></li>
            </ul>
          </div>


        </div>
      </div>
    </div>

    <div class="footer-bottm">
      <div class="d-flex w-100  text-center text-lg-center">
        <div class="copyright w-100 text-center">
           <h5><?php echo  ($this->data['lang']=='en')?@$static_content['all_rights']:@$static_content['all_rights_ar']; ?></h5>
		   <p><?php echo  ($this->data['lang']=='en')?@$static_content['test']:@$static_content['test_ar']; ?>
</p>
        </div>
      </div>
      
    </div>
  </footer><!-- End Footer -->
  
  </div>
  
  <!-- Vendor JS Files -->
  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>assets/website/js/aos.js"></script>
  <script src="<?php echo base_url(); ?>assets/website/js/bootstrap.bundle.min.js"></script>
  <script src='<?php echo base_url(); ?>assets/website/js/moment.min.js'></script>
  <script src='<?php echo base_url(); ?>assets/website/js/jquery.min.js'></script>
  <script src="<?php echo base_url(); ?>assets/website/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/website/js/swiper-bundle.min.js"></script>
<script>
      var swiper = new Swiper(".leaderShip-SpotlightSlider", {
        slidesPerView: 1,
        spaceBetween: 10,
		pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        if(swiper.isEnd){
    
    $("#prosegui").removeClass("swiper-button-disabled");
    $("#prosegui").removeClass("swiper-button-lock");
    $("#prosegui").removeAttr("disabled");
    $("#prosegui").removeAttr("tabindex");
    $("#prosegui").removeAttr("aria-disabled");
    $("#prosegui").removeAttr("aria-controls");
},
      });
</script>
<script>
      var swiper = new Swiper(".vHappening-slider", {
        slidesPerView: 1,
        spaceBetween: 10,
		navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
		pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });
</script>


<script>
var Swiper = new Swiper('.nav-tabs-slider', {
  loop: true,
  pagination: {
    el: '.swiper-pagination',
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
//   scrollbar: {
//     el: '.swiper-scrollbar',
//   },
})

</script>


  <!--<script src="js/main.js"></script>-->
  
 <script src='<?php echo base_url(); ?>assets/website/js/fullcalendar.min.js'></script>
<script src='<?php echo base_url(); ?>assets/website/js/theme-chooser.js'></script>
  <!--<script src="js/main.js"></script>-->
  

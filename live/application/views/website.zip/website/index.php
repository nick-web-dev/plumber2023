<style>
span#calendarTitle {
    display: none !important;
}
.subscribe-image {
    cursor: pointer;
    display: none !important;
}
.headerNav.pl-0 {
    padding-left: 0px;
    list-style: none;
}

</style>
<body>
<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="headerHome  align-items-center">
        <div class="row" >
	<div class="col-lg-4 col-md-4 col-sm-4">
	<div class="logoDiv d-flex align-items-center justify-content-left">
		<div class="logo_headerDiv"><a href="<?php echo base_url();?>"><img src="<?php echo base_url(); ?>assets/website/images/logo-header.png" class="img-fluid" alt=""></a></div>
	</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6">
	<div class="headerCenterDiv d-flex align-items-center justify-content-center">
		<div class="headerCenterImgDiv"><a href="<?php echo base_url();?>">
		    Davita KSA - Teammate Home
		    <!--<img src="<?php echo base_url(); ?>assets/website/images/logo-header-center.png" class="img-fluid logo-footer" alt="">-->
		    </a></div>
	</div>

	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<!--<ul class="headerNav  text-right d-flex">-->
		    <!--<li style="margin-right:10px"><a href="<?php echo base_url();?>website/website_logout" style="font-size:13px;font-weight:600">Logout</a></li>-->
		<!--     <?php if($this->session->userdata['lang']=='en'){?>-->
		<!--     <li><a onclick="set_session('ar')">Ar</a></li>-->
		<!--	<?php } else {?>-->
		<!--	 <li><a onclick="set_session('en')">En</a></li>-->
		<!--	<?php } ?>-->
		<!--</ul>-->
	
                                      
		          
	<!--</div>-->
	<!--<div class="headerLanguageDiv d-flex align-items-end justify-content-end">-->
	<!--	<ul class="headerNav  text-right">-->
	<!--	     		     <li><a onclick="set_session('ar')">Ar</a></li>-->
	<!--				</ul>-->
		          
	<!--</div>-->
	
	                             
                                      
	</div>
	   <div class="dash_notifi">
                                        <ul class="navbar-nav align-items-center d-md-flex user__icon">
                                            <li class="nav-item dropdown">
                                              <a class="nav-link" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <div class="media">
                                                    
                                                              <?php   $session_data=$this->session->userdata('check_user');
           $user_data=$this->db->select('*')->from('users')->where("user_id",$session_data['user_id'])->get()->row_array();?>
                                                  <div class="media-body ">
                                                    <span><?php echo $user_data['username']?><i class="fa fa-angle-down"></i> </span>
                                                  </div>
                                                </div>
                                              </a>
                                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink" >
                                               
                                                <div class="dropdown-item">
                                                      	<ul class="headerNav pl-0">
                                                		     <?php if($this->session->userdata['lang']=='en'){?>
                                                		  <a onclick="set_session('ar')">  <li>Ar</li></a>
                                                			<?php } else {?>
                                                	<a onclick="set_session('en')">	 <li>En</li></a>
                                                			<?php } ?>
                                                		</ul>
                                                </div>
                                                <div class="dropdown-divider"></div>
                                                <a href="<?php echo base_url();?>website/website_logout" class="dropdown-item">
                                                  <span>Logout</span>
                                                </a>
                                              </div>
                                            </li>
                                          </ul>
                                      </div>
    </div>
	</div>
  </header>
  <section class="banner-section">
	<div class="banner-sectionmain">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<div class="leaderShip-SpotlightDiv spot-slider">
					<a href="<?php echo base_url(); ?>website/leadership_message"><div class="leaderShip-SpotlightImgDiv">
						<img src="<?php echo base_url().$leadership['image']; ?>" class="img-fluid" alt="">
						<div class="leaderShip-Spotlight-title"><h3> <?php echo  ($this->data['lang']=='en')?@$leadership['title']:@$leadership['title_ar']; ?></h3></div>
					</div></a>
				</div>
				
				<div class="leaderShip-SpotlightDiv">
					<div class="leaderShip-SpotlightSlider ">
						<div class="leaderShip-SpotlightSlider swiper">
						<div class="swiper-wrapper align-items-center">
						       <?php if(!empty($spotlight)){
        foreach($spotlight as $key=> $spotlights){?>
							<div class="swiper-slide">
							<div class="swiper_item">
							<img src="<?php echo base_url().$spotlights['image']; ?>" class="img-fluid" alt="">
							<div class="leaderShip-Spotlight-title"><h3><?php echo  ($this->data['lang']=='en')?@$spotlights['title']:@$spotlights['title_ar']; ?></h3><a href="<?php echo base_url(); ?>website/spotlight" class="view-all"><?php echo  ($this->data['lang']=='en')?@$static_content['view_all']:@$static_content['view_all_ar']; ?></a></div>
							</div>
							</div>
							 <?php } } else{?>
       <h4 style="color:red;">No data found</h4>
      <?php }?>

						
						</div>
						<div class="swiper-pagination"></div>
					</div>
					
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<div class="vCommunicatin-omDiv">
					<div class="vCommunicatin-omImgDiv"><img src="<?php echo base_url().$village_Communications['image']; ?>" class="img-fluid" alt=""></div>
					<div class="leaderShip-Spotlight-title"><h3><?php echo  ($this->data['lang']=='en')?@$village_Communications['title']:@$village_Communications['title_ar']; ?></h3> <a href="<?php echo base_url(); ?>website/village_communication" class="view-all"><?php echo  ($this->data['lang']=='en')?@$static_content['view_all']:@$static_content['view_all_ar']; ?></a></div>
				</div>
				<?php
				 $arr = explode("-", $oasis_magazine['date']);
                 $day  = date('d', strtotime($oasis_magazine['date']));
                 $date=$day.'/'.$arr[1];
				?>
				
				<div class="oasis-mgDiv">
					<div class="oasis-mgImgDiv"><img src="<?php echo base_url().$oasis_magazine['image']; ?>" class="img-fluid" alt=""> <span class="post-date"><?php echo $date;?></span></div>
					<div class="browseByBeedImg-title"><h3><?php echo  ($this->data['lang']=='en')?@$oasis_magazine['title']:@$oasis_magazine['title_ar']; ?></h3> <a href="<?php echo base_url(); ?>website/oasis_magazine" class="view-all"><?php echo  ($this->data['lang']=='en')?@$static_content['view_all']:@$static_content['view_all_ar']; ?></a></div>
				</div>
				
				
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ">
				<div class="villageHappeningsDiv village-box ">
					<div class="vHappening-slider swiper">
						<div class="swiper-wrapper align-items-center">
						      <?php if(!empty($village_happening)){
        foreach($village_happening as $key=> $villagehappening){?>
							<div class="swiper-slide">
							<div class="swiper_item villager-slider"><a href="<?php echo base_url(); ?>website/village_happenings">
							<img src="<?php echo base_url().$villagehappening['image']; ?>" class="img-fluid" alt="">
							<div class="leaderShip-Spotlight-title"><h3><?php echo  ($this->data['lang']=='en')?@$villagehappening['title']:@$villagehappening['title_ar']; ?></h3></div>
							</a></div>
							</div>
										 <?php } } else{?>
       <h4 style="color:red;">No data found</h4>
      <?php }?>

						</div>
						<div class="swiper-pagination"></div>
						  <!-- navigation buttons -->
					  <div id="js-prev1" class="swiper-button-prev"></div>
					  <div id="js-next1" class="swiper-button-next"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
 
 <section class="askquerries-section">
 <div class="row">
 <div class="container">
 <p><?php echo  ($this->data['lang']=='en')?@$static_content['please_ask_title']:@$static_content['please_ask_title_ar']; ?>  <a  href="<?php echo $mylinks[0]['link']; ?>" target="_blank" class="color-orange"><?php echo  ($this->data['lang']=='en')?@$static_content['click_here']:@$static_content['click_here_ar']; ?></a></p>
 </div>
 </div>
 </section>
 
 
 <section class="myLinks-eventCalender">
	<div class="d-flex align-items-center">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-5 ">
				<div class="mylinks-div">
					<h3><?php echo  ($this->data['lang']=='en')?@$static_content['my_link_title']:@$static_content['my_link_title_ar']; ?></h3>
					<p><?php echo  ($this->data['lang']=='en')?@$static_content['my_link']:@$static_content['my_link_ar']; ?></p>
					<ul class="list-inline">
						<li><a  href="<?php echo $mylinks[1]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[1]['title']:@$mylinks[1]['title_ar']; ?></a></li>
						<li><a  href="<?php echo $mylinks[2]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[2]['title']:@$mylinks[2]['title_ar']; ?></a></li>
						<li><a  href="<?php echo base_url(); ?>website/ps_policies"><?php echo  ($this->data['lang']=='en')?@$static_content['policies']:@$static_content['policies_ar']; ?></a></li>
						<li><a  href="<?php echo $mylinks[3]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[3]['title']:@$mylinks[3]['title_ar']; ?></a></li>
						<li><a  href="<?php echo $mylinks[4]['link']; ?>" target="_blank"><?php echo  ($this->data['lang']=='en')?@$mylinks[4]['title']:@$mylinks[4]['title_ar']; ?></a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-7 col-md-7 col-sm-7">
				<div class="eventCalender-div">	
					<h3 class="text-center"><?php echo  ($this->data['lang']=='en')?@$static_content['calendar']:@$static_content['calendar_ar']; ?></h3>
					<div id="calendar"></div>
					<!--<iframe src="https://calendar.google.com/calendar/embed?src=ketha.manikanta8%40gmail.com&ctz=Asia%2FKolkata" style="border: 0" width="800" height="600" frameborder="0" scrolling="no"></iframe>-->
					<ul class="d-inline">
						<li class="red-clr"><a href="javascript:" ><?php echo  ($this->data['lang']=='en')?@$static_content['event']:@$static_content['event_ar']; ?></a></li>
						<li class="merun-clr"><a href="javascript:"><?php echo  ($this->data['lang']=='en')?@$static_content['party']:@$static_content['party_ar']; ?></a></li>
						<li><a href="javascript:"><?php echo  ($this->data['lang']=='en')?@$static_content['holidays']:@$static_content['holidays_ar']; ?></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
 </section>

<!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container footer-top">
      <div class="footer-topmain">
        <div class="row">

          <div class="col-lg-3 col-md-3 footer-contact">
            <div class="logo_footerDiv"><img src="<?php echo base_url(); ?>assets/website/images/logo-white.png" class="img-fluid logo-footer" alt=""></div>
          </div>

          <div class="col-lg-6 col-md-6 footer-links">
            <p><?php echo  ($this->data['lang']=='en')?@$static_content['please_ask_title']:@$static_content['please_ask_title_ar']; ?>  <a  href="<?php echo $mylinks[0]['link']; ?>" target="_blank" class="color-orange"><?php echo  ($this->data['lang']=='en')?@$static_content['click_here']:@$static_content['click_here_ar']; ?></a></p>
          </div>
		  
		  <div class="col-lg-3 col-md-3 footer-links social-div3">
            <h4><?php echo  ($this->data['lang']=='en')?@$static_content['socail_media']:@$static_content['socail_media_ar']; ?> </h4>
           <ul>
              <li><a href="<?php echo $static_content['twitter_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon1.png" class="img-fluid" alt=""></a></li>
              <li><a href="<?php echo $static_content['instagram_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon2.png" class="img-fluid" alt=""></a></li>
              <li><a href="<?php echo $static_content['linked_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon3.png" class="img-fluid" alt=""></a></li>
			  <li><a href="<?php echo $static_content['web_link']; ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/website/images/social-icon4.png" class="img-fluid" alt=""></a></li>
            </ul>
          </div>


        </div>
      </div>
    </div>

    <div class="footer-bottm">
      <div class="d-flex w-100  text-center text-lg-center">
        <div class="copyright w-100 text-center">
             <h5><?php echo  ($this->data['lang']=='en')?@$static_content['all_rights']:@$static_content['all_rights_ar']; ?></h5>
		   <p><?php echo  ($this->data['lang']=='en')?@$static_content['test']:@$static_content['test_ar']; ?>
</p>
        </div>
      </div>
      
    </div>
  </footer><!-- End Footer -->
  
  </div>
  <script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>
    
  
  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>assets/website/js/aos.js"></script>
  <script src="<?php echo base_url(); ?>assets/website/js/bootstrap.bundle.min.js"></script>
  <script src='<?php echo base_url(); ?>assets/website/js/moment.min.js'></script>
  <script src='<?php echo base_url(); ?>assets/website/js/jquery.min.js'></script>
  <script src="<?php echo base_url(); ?>assets/website/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/website/js/swiper-bundle.min.js"></script>
<script>
      var swiper = new Swiper(".leaderShip-SpotlightSlider", {
        slidesPerView: 1,
        spaceBetween: 10,
		autoplay: {
		  delay: 5000,
		},
		pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });
    </script>
<script>
      var swiper = new Swiper(".vHappening-slider", {
        slidesPerView: 1,
        spaceBetween: 10,
		autoplay: {
		  delay: 4000,
		},
		navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
		pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });
    </script>
  <!--<script src="js/main.js"></script>-->
  
 <script src='<?php echo base_url(); ?>assets/website/js/fullcalendar.min.js'></script>
<script src='<?php echo base_url(); ?>assets/website/js/theme-chooser.js'></script>
<style>
    .fc-content1{
            background-color: #D20F55 !important;
    }
    .fc-content2{
            background-color: #641480 !important;
    }
     .fc-content3{
            background-color: #0068b1 !important;
    }
</style>
<script>

	$(document).ready(function() {

		initThemeChooser({

			init: function(themeSystem) {
				$('#calendar').fullCalendar({
				
		header: {
		left: 'prev,next today',
		center: 'title',
		right: 'month,agendaWeek,agendaDay,listMonth'
		},
// 			defaultDate: '2021-10-14',
			weekNumbers: true,
			navLinks: true, // can click day/week names to navigate views
			editable: true,
		   eventLimit: true,
		   eventOrder : 'sort',
           eventRender: function (event, element){
          element.find('.fc-title').html(event.title);
          element.find('.fc-event-title').html(event.title);
         },
					events: [
					       <?php  
                   foreach (@$slots as $key => $value) { 
                     $start=strtotime($value['start_time']);
                     $start_time=date("g:i a",$start);
                        if($this->session->userdata['lang']=='en'){
                     $title_m=trim($value['name']);
                        } else{
                          $title_m=trim($value['name_ar']);  
                        }
                     ?>
						{
						    <?php if($value['type']==1){?>
							title:'<div class="fc-content1"><span class="fc-title1"><?php echo $start_time."-".$title_m; ?></span></div>',
							<?php } else if($value['type']==2){?>
							title:'<div class="fc-content2"><span class="fc-title1"><?php echo $start_time."-".$title_m; ?></span></div>',
							<?php } else{?>
							title:'<div class="fc-content3"><span class="fc-title1"><?php echo $start_time."-".$title_m; ?></span></div>',
							<?php }?>
							start: '<?php echo $value["start_date"];?>',
							end:'<?php echo $value["end_date"];?>'
						},
		
        <?php  } ?>
					
					
					]
				});
			},

			change: function(themeSystem) {
				$('#calendar').fullCalendar('option', 'themeSystem', themeSystem);
			}

		});

	});

</script>
<script type="text/javascript" src="js/bootstrap/bootstrap-dropdown.js"></script>
<script>
     $(document).ready(function(){
        $('.dropdown-toggle').dropdown()
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>


</body>
</html>



<body>

<div class="bodydiv">
  <!-- ======= Header ======= -->
  <header id="header" class="blue-header d-flex align-items-center">
    <div class="header-innerPages d-flex align-items-center">
	<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	<div class="header-headingBreadcumb">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2><?php echo  ($this->data['lang']=='en')?@$static_content['oasis_magazine']:@$static_content['oasis_magazine_ar']; ?></h2></div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><ul class="">
			<li><a href="<?php echo base_url(); ?>website/index"><?php echo  ($this->data['lang']=='en')?@$static_content['home']:@$static_content['home_ar']; ?></a></li>
			<li><img src="<?php echo base_url(); ?>assets/website/images/next.png" class="img-fluid" alt=""></li>
			<li><?php echo  ($this->data['lang']=='en')?@$static_content['oasis_magazine']:@$static_content['oasis_magazine_ar']; ?></li>
		</ul></div>
	</div>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-2">
    <div class="headerLanguageDiv d-flex align-items-end justify-content-end">
		<ul class="headerNav text-right">
		  <?php if($this->session->userdata['lang']=='en'){?>
		     <li><a onclick="set_session('ar')">Ar</a></li>
			<?php } else {?>
			 <li><a onclick="set_session('en')">En</a></li>
			<?php } ?>
			
		</ul>
	</div>  

	</div>
    
	</div>
  </header>
  <script>
        function set_session(lang)
        {
           $.ajax({                
                    url: "<?php echo base_url();?>website/set_session/"+lang,
                    type: "POST",
                    data: '',
                    error:function(request,response){
                        console.log(request);
                    },                  
                    success: function(result){
                        if(result) {
                          location.reload();  
                          console.log();
                        } 

                    }

                });
        }
    </script>
    

  <section class="villageCommunicationPage-section">
	<div class="villageCommunicationPageMainDiv">
		<div class="row">
		    <?php if(!empty($oasis_magazine_images)){
        foreach($oasis_magazine_images as $key=> $oasismagazineimages){?>
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 ">
				<div class="oasis-magazineImgPageDiv-Item">
				    <?php if($oasismagazineimages['type']==1){?>
					<a href="<?php echo $oasismagazineimages['link'];?>" target="_blank"><img src="<?php echo base_url().$oasismagazineimages['image']; ?>" class="img-fluid" alt="" style="height: 353px;width: 282px;"></a>
				<?php } else {?>
					<a href="<?php echo base_url().$oasismagazineimages["pdf"];?>" target="_blank"><img src="<?php echo base_url().$oasismagazineimages['image']; ?>" class="img-fluid" alt="" style="height: 353px;width: 282px;"></a>
				<?php }?>
				</div>
				<br>
			</div>
		 <?php } } else{?>
       <h4 style="color:red;">No data found</h4>
      <?php }?>
		</div>
	</div>
</section>
  
 

<!-- ======= Footer ======= -->
 
  
  </div>

</body>
</html>



<!DOCTYPE html>
<html lang="en">
<style>
.btn-primary, .btn-primary:focus, .btn-primary:hover {
    background-color: #ffd600 !important;
    border-color: #CE9F49 !important;
    
}
.sign-text {
    color: black !important;
}
.popover {
   z-index: 2000;
   position: relative;
 }
 .video_background {
			    background: url(<?php echo base_url(); ?>assets/website/images/inner_layer2.png);
				
			    background-size: 100%;
			    background-repeat: no-repeat;
			}
.error {
    text-transform: inherit !important;
}
</style>
<head>
	<title>Call the Plumber</title>
	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta name="description" content="Phoenixcoded">
	<meta name="keywords"
		  content=", Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
	<meta name="author" content="Phoenixcoded">

	<!-- Favicon icon -->
	<link rel="shortcut icon" href="<?php echo base_url();?>assets/website/images/favicon.png" tppabs="http://ableproadmin.com/light/vertical/assets/website/img/logo.png" type="image/x-icon">
	<link rel="icon" href="<?php echo base_url();?>assets/website/images/favicon.png" tppabs="http://ableproadmin.com/light/vertical/assets/website/img/logo.png" type="image/x-icon">

	<!-- Google font
	<link href="fonts.googleapis.com/css-family=Open+Sans-300,400,600,700,800.css" tppabs="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">-->

	<!-- Font Awesome -->
	<link href="<?php echo base_url();?>assets/css/font-awesome.min.css" tppabs="http://ableproadmin.com/light/vertical/assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!--ico Fonts-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/icofont.css" tppabs="http://ableproadmin.com/light/vertical/assets/icon/icofont/css/icofont.css">

	<!-- Required Fremwork -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.min.css" tppabs="http://ableproadmin.com/light/vertical/assets/css/bootstrap.min.css">

	<!-- waves css -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/waves/css/waves.min.css" tppabs="http://ableproadmin.com/light/vertical/assets/plugins/waves/css/waves.min.css">

	<!-- Style.css -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/main.css" tppabs="http://ableproadmin.com/light/vertical/assets/css/main.css">

	<!-- Responsive.css-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/responsive.css" tppabs="http://ableproadmin.com/light/vertical/assets/css/responsive.css">	

</head>
<body style="background-image: url(<?php echo base_url(); ?>assets/website/img/banner.png);">
<!--style="background-image: url(<?php echo base_url(); ?>assets/website/images/footer_v.mp4);"-->
<section class="login p-fixed d-flex text-center  common-img-bg">
	<!-- Container-fluid starts -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				
<!--modal-->
				<div class="login-card card-block" style="background:white">
					<form class="md-float-material" id="loginform" method="POST" action="<?php echo base_url();?>admin/login">
						
						<div class="text-center">
							<img src="<?php echo base_url();?>assets/website/img/logo.png" style="width:84% !important;margin-left:-85px;height: 113px;">
						</div>
						<h3 class="text-center sign-text" >
							Sign in to your account
						</h3>
						<div class="alert alert-danger" id="login_error_tab" style="display:none;">
					<a href="#" class="" data-dismiss="alert" style="float: right;margin-top: -20px;">&times;</a>
					<span  id="login_error_msg"></span>
				</div>
						
						<div>
						
							<input type="email" class="md-form-control" name="data[email]" value="" placeholder="Email"/>
							
						</div>
						<div>
						
						<input type="password" class="md-form-control" name="data[password]" value="" placeholder="Password" />
							
						</div>
						<div class="row">
							<div class="col-sm-6 col-xs-12">
							<!-- <div class="rkmd-checkbox checkbox-rotate checkbox-ripple m-b-25">
								<label class="input-checkbox checkbox-primary">
									<input type="checkbox" id="checkbox">
									<span class="checkbox"></span>
								</label>
								<div class="captions">Remember Me</div>

							</div> -->
								</div><br>
							<div class="col-xs-12 forgot-phone text-right">
								<a href="<?php echo base_url();?>home/forgot_password"  class="text-right f-w-600"> Forgot Password?</a>
								</div>
						</div><br>
						<div class="row">
							<div class="col-xs-10 offset-xs-1">								
								<input type="submit" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20" name="submit" value="LOGIN">
							</div>
						</div>
						<!-- <div class="card-footer"> 
						<div class="col-sm-12 col-xs-12 text-center">
							<span class="text-muted">Don't have an account?</span>
							<a href="register2.html" tppabs="http://ableproadmin.com/light/vertical/register2.html" class="f-w-600 p-l-5">Sign up Now</a>
						</div>-->

						<!-- </div> -->
					</form>
					<!-- end of form -->
				</div>
				<!-- end of login-card -->
			</div>
			<!-- end of col-sm-12 -->
		</div>
		<!-- end of row -->
	</div>
	<!-- end of container-fluid -->
</section>


<!-- Warning Section Ends -->
<!-- Required Jqurey -->
<script src="<?php echo base_url();?>assets/js/jquery-3.1.1.min.js" ></script>
<script src="<?php echo base_url();?>assets/js/jquery-ui.min.js" ></script>
<script src="<?php echo base_url();?>assets/js/jquery.validate.js" ></script>
<!-- tether.js -->
<script src="<?php echo base_url();?>assets/js/tether.min.js" ></script>
<!-- waves effects.js -->
<script src="<?php echo base_url();?>assets/plugins/waves/js/waves.min.js" ></script>
<!-- Required Framework -->
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js" ></script>
<!-- Custom js -->
<script type="text/javascript" src="<?php echo base_url();?>assets/pages/elements.js" ></script>
</body>
</html>
<script>
	$("#loginform").validate({       
            rules: {
               
                "data[email]"              : "required",
                "data[password]"           : "required"
            },
               
    });
	
 
    </script>
	   <?php 
    	if(isset($error)){ ?>

    	<script>
    		$("#login_error_tab").css("display", "block");
			$('#login_error_tab').show().delay(2500).fadeOut('slow');
			$("#login_error_msg").html('<?php echo $error;?>');
    	</script>

	<?php   $error=""; }
    ?>
 
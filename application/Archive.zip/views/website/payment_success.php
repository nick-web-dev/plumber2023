
	<!-- Menu css E -->

				<!-- /*================ all_banner section  S================*/ -->


	<section class="vs_all_banner">
		<div class="container">
			<div class="vs_all_banner_head">
				<h1>PAYMENT SUCCESS!</h1>
			</div>
		</div>
	</section>

				<!-- /*================ all_banner section E================*/ -->

				<!-- ===============payment_success section S================= -->

	<section class="vs_payment_success py-5">
		<div class="container">
			<div class="vs_payment_success_head pb-4">
				<div class="text-center">
					<img src="<?php echo base_url(); ?>assets/website/img/Group 8921.png" class="img-fluid py-sm-5">
				</div>
				<h1 class="py-4"><b>PAYMENT SUCCESS!</b></h1>
				<p >Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat.</p>
				<div class="vs_payment_form_button text-center pt-4 py-5">
				    <a href="<?php echo base_url()?>"><button type="submit" class="btn">GET STARTED</button></a>
				</div>
			</div>
		</div>
	</section>

</body>
</html>
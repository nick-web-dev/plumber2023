<div class="mains">
<h1 >we are temp down for repairs</h1>
<image src="https://calltheplumber.com/assets/website/img/plumberlogo3.png">
</div>
<style>
    
    .mains {
    text-align: center;
    font-size:45px;
    text-transform:capitalize;
}
img {
    text-align: center !important;
}

</style>
<style>
   .modal-header .close {
     margin-right: -64% !important;
    margin-top: -40px !important;
   }
   .modal-title {
           margin-right: 196px;
   }
</style>

<div class="modal-dialog" role="document">
    <div class="modal-content" style="overflow:hidden">
        <div class="modal-header" style="border-bottom-color: #ccc;background-color: #ffd600;">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" align="center">Details</h4>
        </div>
        <div class="modal-body">
            <form id="insert_banners">
               <div class="form-group row">
                  <label class="col-sm-12 col-form-label form-control-label">
                      <span><?=$value->description?></span>
                      
                  </label>
                    
                </div>
                
               
			
    </div>
    </div>
</div>

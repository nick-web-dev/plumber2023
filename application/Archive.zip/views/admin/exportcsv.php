<Style>
.md-input-wrapper {
    margin-bottom: 29px !important;
}
.md-input-wrapper {
    margin-bottom: 0px !important;
}
.md-input-wrapper .md-form-control {
    padding: 5px !important;
}
#advanced-table_filter label {
    top: 100px !important;
}
</style>
<!-- CONTENT-WRAPPER-->
<div class="content-wrapper">
    <!-- Container-fluid starts -->
  <div class="container-fluid">
    <!-- Row Starts -->
    <div class="row">
      <div class="col-sm-12">
        <div class="main-header">
          <!--<h4>Blogs</h4>-->
        </div>
      </div>
    </div>
    <!-- Row end -->
    <div class="row">
      <div class="col-sm-12">        
        <div class="card">
          <div class="card-header"><h5 class="card-header-text"></h5><span>
          <a href="<?php echo base_url()?>admin/export_csv"><button class="btn btn-success" style="margin-left: 36%;margin-top: 7px;">Export Csv</button></a></span></div>
		    <!--<span><button type="button" class="btn btn-success fa fa-plus add_banners" data-name="<?php echo @$current_page; ?>" style="margin-left:86%;"> Add blog</button></span>-->
              <!--</div>-->
          <div class="card-block">
           
          </div>
        </div>
      </div>
    </div>
  </div>
        <!-- Container-fluid ends -->
        
     </div>
 <!-- CONTENT-WRAPPER-->
  <section>
      <div class = "modal fade" data-backdrop="static" data-keyboard="false" id = "add_banners" tabindex = "-1" role = "dialog" aria-labelledby = "myModalLabel" aria-hidden = "true"></div>
     <div class = "modal fade" data-backdrop="static" data-keyboard="false" id = "add_banners1" tabindex = "-1" role = "dialog" aria-labelledby = "myModalLabel" aria-hidden = "true"></div>
    </section>
  
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Contact us</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
</head>
<body style="font-family: 'Open Sans',sans-serif; margin:0px auto; font-size:15px; width:100%;">
<div class="main-div"  style="margin:20px auto; height:auto;border: 1px solid #ccc;width: 184%;">
  <div class="content" style="width:100%; margin:0px auto;">
    <div class="top-header" style="width: 100%;padding-bottom: 100px;padding-top: 10px;background: #ffd600  !important;border-bottom: 1px solid #ccc;">
      <div class="logo" style=" float:left; width:22%"> 
        <a href="<?php echo base_url();?>"> <img  src="<?php echo base_url();?>assets/website/img/logo.png" alt="logo" style="width: 171px;height: 90px;margin-left: 10px;"></a> </div>
      <div class="header-content" style=" float:left; width:70%">
      <h3 class="" style="margin-bottom: 0px;font-size: 25px;color: white !important;font-weight: 600;line-height: 18px;margin-top: 35px;  text-transform: uppercase;text-align: center;">Contact us</h3>
    
      </div>
    </div>
    <div class="content" style="width:100%;padding: 15px 20px;">
      <!-- <p style="width:90%; text-transform:uppercase ;text-align:center;    font-size: 20px;
    color: #0d7e52;"><strong>Password Details</strong></p> -->
      <p style="margin-bottom:10px;text-align:center;width: 25%;
    float: left;"><strong>Name</strong><span style="width: 10%;
    float: right;">:</span></p>
      <p style="text-align:left;width: 75%;
    float: left;width: 70%;
    float: left;    padding-left: 20px;">{name}</p>
    <div class="clearifx" style="clear:both"></div>
    
      <p style="margin-bottom: 0px;text-align:center;width: 25%;
    float: left;"><strong>Email</strong><span style="width: 10%;
    float: right;">:</span></p>
      <p style="text-align:left;width: 70%;
    float: left;    padding-left: 20px;">{email}</p>
       <div class="clearifx" style="clear:both"></div>
         <p style="margin-bottom: 0px;text-align:center;width: 25%;
    float: left;"><strong>Subject</strong><span style="width: 10%;
    float: right;">:</span></p>
      <p style="text-align:left;width: 70%;
    float: left;    padding-left: 20px;">{subject}</p>
       <div class="clearifx" style="clear:both"></div>
       
        <p style="margin-bottom: 0px;text-align:center;width: 25%;
    float: left;"><strong>message</strong><span style="width: 10%;
    float: right;">:</span></p>
      <p style="text-align:left;width: 70%;
    float: left;    padding-left: 20px;">{message}</p>
       <div class="clearifx" style="clear:both"></div>
      </div>
     <div style="background-color: #ffd600  !important; padding: 2px 20px;">
      <p align="center" style="  font-size: 13px;
    color: white;
    letter-spacing: 0.5px;
    font-weight: 600;">
    Copyright <span>&copy;<span>2021 <a href="javascript:" style="color:white !important; text-decoration:none;">Call the plumber</a> All Rights Reserved
    </p>
    </div>
  </div>
</div>
</body>
</html>
<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');


	class Services_m extends CI_Model {
        
	

}